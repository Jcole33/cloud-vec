var _a;
import SSM from 'aws-sdk/clients/ssm.js';
if (!process.env.PARSEC_PASSWORD)
    throw 'MISSING API KEY ENV!';
const ENCRYPTED_NAME = process.env.PARSEC_PASSWORD;
const { Parameters } = await (new SSM({ region: process.env.TABLE_REGION }))
    .getParameters({
    Names: [ENCRYPTED_NAME],
    WithDecryption: true,
})
    .promise();
const password = (_a = Parameters === null || Parameters === void 0 ? void 0 : Parameters.find((param) => param.Name == ENCRYPTED_NAME)) === null || _a === void 0 ? void 0 : _a.Value;
if (!password)
    throw 'MISSING REAL API KEY!';
export { password };
